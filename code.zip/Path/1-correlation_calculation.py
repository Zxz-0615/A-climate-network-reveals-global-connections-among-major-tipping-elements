import numpy as np
import netCDF4 as nc
import pandas as pd
import numpy.ma as ma
from numba import jit
import h5py
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
from geopy.distance import geodesic

absolute_address = 'D:\\climate_network\\test\\'
read_address = absolute_address + '\\240423\\'
f = h5py.File(read_address+'\\path_remove_season_years.h5','r')
lat = f['lat'][:]
lon = f['lon'][:]
data = f['data'][:]

C_ij = np.zeros((len(lat),len(lon),len(lat),len(lon)))
W_ij = np.zeros((len(lat),len(lon),len(lat),len(lon)))
tau_ij = np.zeros((len(lat),len(lon),len(lat),len(lon)))


#计算结点相关性（所有年份数据为一个序列）
def cross_correlation(inside,outside):
    #序列长度为所有年份时间长度减一年
	length = len(inside)-365
    #设置最大滞后
	tau_max = 201
	
	value_positive = []
	value_negative = []
	
	temp_1 = (inside[:length]-np.mean(inside[:length]))/np.std(inside[:length])
	temp_2 = (outside[:length]-np.mean(outside[:length]))/np.std(outside[:length])
	value_positive.append(np.mean(temp_1*temp_2))
	
	for tau in range(1,tau_max,1):
		out_data = outside[tau:tau+length]
		in_data = inside[tau:tau+length]
		# move out_data
		value_positive.append(np.mean(temp_1*((out_data-np.mean(out_data))/np.std(out_data))))
		# move in_data
		value_negative.append(np.mean(temp_2*((in_data-np.mean(in_data))/np.std(in_data))))
		
	value_series = np.array(value_positive+value_negative)
	return value_series

for m in range(0,len(lat),1):
    for n in range(0,len(lon),1):
        for i in range(0,len(lat),1):
            for k in range(0,len(lon),1):
                point_1 = (lat[m],lon[n])
                point_2 = (lat[i],lon[k])
                if geodesic(point_1,point_2).km<1000:
                    cross_corr_series = cross_correlation(data[i,k,:],data[m,n,:])
                    peak_value = max(cross_corr_series.min(), cross_corr_series.max(), key=abs)
                    C_ij[m][n][i][k] = peak_value
                    W_ij[m][n][i][k] = (peak_value-np.mean(cross_corr_series))/(np.std(cross_corr_series))
                    peak_tau = np.where(cross_corr_series == peak_value)[0][0]
                    tau_ij[m][n][i][k] = peak_tau
    print(str(m))

save_address = absolute_address+'\\path\\corr_600.h5'	
f = h5py.File(save_address,'w')
f['C'] = C_ij
f['W'] = W_ij
f['tau'] = tau_ij
f.close()