#全部路径
import matplotlib.pyplot as plt
import numpy as np
import h5py
import pandas as pd
import networkx as nx
from geopy.distance import geodesic
from mpl_toolkits.basemap import Basemap
from matplotlib import font_manager

# 设置字体
font_path = '/nfs/home/2113_xujialu/.conda/envs/pytorch2.1-cuda12.1/lib/python3.10/site-packages/matplotlib/mpl-data/fonts/ttf/ARIAL.TTF'
prop = font_manager.FontProperties(fname=font_path)
plt.rcParams['font.family'] = prop.get_name()

# 创建经纬度格点函数
def creat_lattic(address): 
    df = pd.read_csv(address, header=None, index_col=False)
    lattic = np.zeros((726, 2))
    lattic[:, 0] = (90 - ((np.floor(df.values[:, 0] / 144) - 1) * 2.5)) - 2.5  # lat
    lattic[:, 1] = np.remainder(df.values[:, 0], 144) * 2.5  # lon
    return lattic

# 读取 lattic 文件
lattic = creat_lattic('/nfs/home/2113_xujialu/zzl/zky/traj/726.dat')
distance_matrix = np.zeros((726, 726))

# 区域名称映射
area_names = {
    1: 'ASI', 
    17: 'GrIS',
    12: 'Permafrost',
    57: 'AMOC',
    716: 'WAIS',
    23: 'BF',
    692: 'EAIS',
    425: 'AMAZ',
}

# 计算地理距离
for i in range(726):
    for j in range(726):
        distance_matrix[i][j] = geodesic((lattic[i, 0], lattic[i, 1]), (lattic[j, 0], lattic[j, 1])).km

# 读取 h5 文件
absolute_address = '/nfs/home/2113_xujialu/zzl/zky/traj/'
address = absolute_address + '726_nodes_result.h5'
f = h5py.File(address, 'r')
C_ij = f['C'][:]
W_ij = f['W'][:]
tau_ij = f['tau'][:]
f.close()

# 构建图
distance_max = 1000
DG = nx.DiGraph()
for i in range(726):
    DG.add_node(i)

for i in range(726):
    for j in range(726):
        if i == j:
            continue
        elif (tau_ij[i][j] < 201) and (distance_matrix[i][j] < distance_max):
            DG.add_weighted_edges_from([(i, j, abs(1 / W_ij[i][j]))])

# 用元组列表表示所有路径
start_end_pairs = [
    (1, 425),   # ASI - AMAZ
    (17, 425),  # GrIS - AMAZ
    (425, 57),  # AMAZ - AMOC
    (425, 716), # AMAZ - WAIS
    (23, 692),  # BF - EAIS
    (716, 12),  # WAIS - Permafrost
    (716, 23),  # WAIS - BF
    (12, 692),  # Permafrost - EAIS
    (12, 425)   # Permafrost - AMAZ
]

# 设置颜色
colors = [
    '#7F7F7F',
    '#FE87D7',
    '#939879',
    '#60A130',
    '#CD9600',
    '#1F8F99',
    '#662F00',
    '#816D34',
    '#F8B296']
color_idx = 0

# 画图
plt.figure(figsize=(16, 9))
m = Basemap(projection='robin', lon_0=0)
m = Basemap(projection='robin', lon_0=0)
m.drawmapboundary(fill_color='white')
m.fillcontinents(color='#DCDCDC', lake_color='white')
m.drawcoastlines(linewidth=0.4, color='black')
# === ✅ 添加类似 Basemap 的阴影地形底图 ===
m.drawmeridians(np.arange(-180, 180, 60), dashes=[5, 5], labels=[1, 0, 0, 1], color='#666b6c', linewidth=0.8, alpha=0.8, size=20, family='Arial', zorder=1)
m.drawparallels(np.arange(-90, 90, 30), dashes=[5, 5], labels=[1, 0, 0, 1], color='#666b6c', linewidth=0.8, alpha=0.8, size=20, family='Arial', zorder=1)
handles = []
# 遍历并绘制路径
from matplotlib.lines import Line2D

for start_point, ending_point in start_end_pairs:
    try:
        path = nx.dijkstra_path(DG, start_point, ending_point)
    except nx.NetworkXNoPath:
        print(f"⚠️ 无路径从 {area_names[start_point]} 到 {area_names[ending_point]}")
        continue

    x_p, y_p = [], []
    for i in path:
        lon, lat = lattic[i, 1], lattic[i, 0]
        x, y = m(lon, lat)
        x_p.append(x)
        y_p.append(y)

    path_color = colors[color_idx % len(colors)]

    # 绘制路径
    m.plot(x_p, y_p, '--', linewidth=2.8, color=path_color, alpha=0.9, zorder=4)

    # 绘制节点
    for i in range(len(x_p)):
        m.plot(x_p[i], y_p[i], marker='o', color=path_color, alpha=0.7, markersize=7.5, zorder=4)
    m.plot(x_p[0], y_p[0], marker='o', color=path_color, alpha=0.9, markersize=12, zorder=4)
    m.plot(x_p[-1], y_p[-1], marker='o', color=path_color, alpha=0.9, markersize=12, zorder=4)

    # ✅ 图例项（使用箭头符号 →）
    handles.append(Line2D([], [], linestyle='--', color=path_color, linewidth=2.8,
                          label=f'{area_names[start_point]} → {area_names[ending_point]}'))

    color_idx += 1
     # 图例
# === 在每个关键区域画星型 ===
for idx, name in area_names.items():
    lat, lon = lattic[idx, 0], lattic[idx, 1]
    x, y = m(lon, lat)
    m.plot(x, y, marker='*', color='red', markersize=18, zorder=5)

# 添加图例
plt.legend(handles=handles,
           loc='upper center',             # 图例锚点位置
           bbox_to_anchor=(0.5, -0.05),    # (x, y)：图例中心在图外下方
           ncol=1,                         # 可选：分多列排版
           fontsize=10,
           frameon=False)


#plt.title("Paths between different TP")
plt.savefig('/nfs/home/2113_xujialu/zzl/zky/traj/Paths除南北极其余部分2.PNG', dpi=500, bbox_inches='tight')
plt.show()
plt.close()