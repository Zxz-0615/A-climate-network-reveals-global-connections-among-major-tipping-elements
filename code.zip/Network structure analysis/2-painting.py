import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.colors import Normalize
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch

# ==================== 字体设置 ====================
font_path = '/nfs/home/2113_xujialu/.conda/envs/pytorch2.1-cuda12.1/lib/python3.10/site-packages/matplotlib/mpl-data/fonts/ttf/ARIAL.TTF'
prop = font_manager.FontProperties(fname=font_path)
plt.rcParams['font.family'] = prop.get_name()
plt.rcParams['font.size'] = 40
sns.set_style("whitegrid")

# ==================== 读取数据 ====================
edges = pd.read_csv(
    "/nfs/home/2113_xujialu/zzl/zky/shuffle_new/two_tp/in_out/region_edge_weights_by_period1010 (2).csv",
    sep=None, engine="python"
)
nodes = pd.read_csv(
    "/nfs/home/2113_xujialu/zzl/zky/shuffle_new/two_tp/in_out/region_weighted_degree_centrality_1010.csv",
    sep=None, engine="python"
)

edges.columns = edges.columns.str.strip()
nodes.columns = nodes.columns.str.strip()

# ==================== 时间段列表 ====================
periods = sorted(edges["period"].unique())

# ==================== 自定义节点颜色 ====================
color_map = {
    "GrIS": "#9ECAE7", "ASI": "#9ECAE7", "Permafrost": "#9ECAE7",
    "WAIS": "#9ECAE7", "EAIS": "#9ECAE7",  # Cryosphere (blue)
    "AMOC": "#F08D2A",                     # Hydrosphere (orange)
    "AMAZ": "#8BD17B", "BF": "#8BD17B"     # Biosphere (green)
}

# ==================== 边权颜色映射 ====================
cmap = plt.get_cmap("YlGnBu")
norm = Normalize(vmin=edges["mean_weight"].min(), vmax=edges["mean_weight"].max())

# ==================== 创建 2x2 子图布局 ====================
ncols, nrows = 2, 2
fig, axes = plt.subplots(nrows, ncols, figsize=(80, 80))
axes = axes.flatten()
plt.subplots_adjust(wspace=0.25, hspace=0.3)

for ax, period in zip(axes, periods):
    e_period = edges[edges["period"] == period]
    n_period = nodes[nodes["period"] == period]

    # ==================== 构建有向图 ====================
    G = nx.DiGraph()
    for _, row in e_period.iterrows():
        G.add_edge(row["from"], row["to"], weight=row["mean_weight"], color=row.get("color", 0))

    # ==================== 节点大小（按加权度） ====================
    degree_dict = dict(G.degree(weight="weight"))
    node_sizes = [degree_dict[n]*9000 if n in degree_dict else 2000 for n in G.nodes()]

    # ==================== 节点颜色 ====================
    node_colors = [color_map.get(n, "#CCCCCC") for n in G.nodes()]

    # ==================== 边颜色与粗细 ====================
    edge_colors = [
        "#C90E2C" if G[u][v].get("color", 0) == 1 else
        "#336A9B" if G[u][v].get("color", 0) == -1 else
        "gray"
        for u, v in G.edges()
    ]
    edge_widths = [max(G[u][v]["weight"] * 9, 0.5) for u, v in G.edges()]

    # ==================== 节点布局（更舒展） ====================
    #pos = nx.spring_layout(G, seed=42, k=1.2)
    pos = nx.shell_layout(G)


    # ==================== 绘制边（粗细与权重相关） ====================
    for (u, v), c, w in zip(G.edges(), edge_colors, edge_widths):
        arrow = FancyArrowPatch(
            posA=pos[u],
            posB=pos[v],
            arrowstyle='-|>',
            color=c,
            lw=w,
            alpha=0.8,
            mutation_scale=40 + w * 2,  # 箭头随权重变化
            shrinkA=node_sizes[list(G.nodes()).index(u)]**0.5 / 2,
            shrinkB=node_sizes[list(G.nodes()).index(v)]**0.5 / 2,
            connectionstyle="arc3,rad=0"  # 更弯，减少与节点交叉
        )
        ax.add_patch(arrow)

        x_mid = (pos[u][0] + pos[v][0]) / 2
        y_mid = (pos[u][1] + pos[v][1]) / 2
        weight = G[u][v]["weight"]
    

        ax.text(
            x_mid, y_mid + 0.03,
            f"{weight:.2f}",
            fontsize=50,
            color=c,               
            ha="center", va="center"
        )

    # ==================== 绘制节点 ====================
    nx.draw_networkx_nodes(
        G, pos, ax=ax,
        node_size=node_sizes,
        node_color=node_colors
    )

    # ==================== 绘制标签 ====================
    nx.draw_networkx_labels(G, pos, ax=ax, font_size=45, font_color="black")
    for node, (x, y) in pos.items():
        value = degree_dict.get(node, 0)  # 你可以换成自己想显示的指标
        ax.text(
            x, y - 0.06,  # 略低于节点
            f"{value:.2f}",  # 保留两位小数
            fontsize=50,
            color="black",
            ha="center", va="top"
        )


    ax.set_title(f"Period: {period}", fontsize=14)
    ax.axis("off")

# 隐藏空子图
for j in range(len(periods), len(axes)):
    axes[j].axis("off")

# ==================== 保存与展示 ====================
plt.savefig(
    "/nfs/home/2113_xujialu/zzl/zky/shuffle_new/two_tp/网络格式2.png",
    dpi=600,
    bbox_inches="tight"
)
plt.show()
