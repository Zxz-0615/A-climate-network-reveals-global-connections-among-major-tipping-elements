import os
import pandas as pd

# 定义主目录
base_dir = "/nfs/home/2113_xujialu/zzl/zky/shuffle_new/two_tp/in_out/spatial/18条边"

# 获取所有区域对文件夹名
region_folders = [f for f in os.listdir(base_dir) if os.path.isdir(os.path.join(base_dir, f)) and "_point_20year" in f]

# 用于汇总结果的列表
all_results = []

# 遍历每个区域组合文件夹
for folder in region_folders:
    folder_path = os.path.join(base_dir, folder)

    # 提取区域对（如 AMOC_GrIS）
    try:
        region_pair = folder.replace("_point_20year", "")
        region_from, region_to = region_pair.split("_")
    except ValueError:
        print(f"⚠️ 跳过非法命名的文件夹：{folder}")
        continue

    # 构造 out 和 in 的文件路径（只用这一对）
    out_file = os.path.join(folder_path, f"{region_from}_out_results_by_period.xlsx")
    in_file  = os.path.join(folder_path, f"{region_to}_in_results_by_period.xlsx")

    # 检查文件是否存在
    if not (os.path.exists(out_file) and os.path.exists(in_file)):
        print(f"❗ 缺失所需文件，跳过：{folder}")
        continue

    # 时间段列表
    periods = ["1941-1960", "1961-1980", "1981-2000", "2001-2022"]

    for period in periods:
        try:
            # 读取对应 sheet
            out_df = pd.read_excel(out_file, sheet_name=period)
            in_df = pd.read_excel(in_file, sheet_name=period)

            # 自动识别第六列（保底处理）
            out_col = [col for col in out_df.columns if col.startswith("newW_") and "_out_" in col][0]
            in_col  = [col for col in in_df.columns  if col.startswith("newW_") and "_in_" in col][0]

            # 取绝对值再求平均
            mean_out = out_df[out_col].abs().mean()
            mean_in  = in_df[in_col].abs().mean()

            # 区域对的最终边权重
            mean_weight = (mean_out + mean_in) / 2

            all_results.append({
                "from": region_from,
                "to": region_to,
                "period": period,
                "mean_weight": mean_weight
            })
        except Exception as e:
            print(f"⚠️ 处理 {folder} - {period} 时出错: {e}")
            continue

# 汇总并保存
results_df = pd.DataFrame(all_results)
results_df.to_csv("/nfs/home/2113_xujialu/zzl/zky/shuffle_new/two_tp/in_out/region_edge_weights_by_period1010.csv", index=False)

print("✅ 成功提取指定方向的区域间平均边权重，并保存结果。")



import pandas as pd
import networkx as nx

# 读取边权重表
df = pd.read_csv("/nfs/home/2113_xujialu/zzl/zky/shuffle_new/two_tp/in_out/region_edge_weights_by_period1010.csv")

# 获取所有时间段
periods = df["period"].unique()

# 记录中心性结果
centrality_results = []

for period in periods:
    # 创建有向加权图
    G = nx.DiGraph()
    
    # 筛选该时间段的数据
    period_df = df[df["period"] == period]
    
    # 添加边（包含权重）
    for _, row in period_df.iterrows():
        G.add_edge(row["from"], row["to"], weight=row["mean_weight"])

    # 计算加权入度和出度中心性
    in_deg = dict(G.in_degree(weight="weight"))
    out_deg = dict(G.out_degree(weight="weight"))

    # 合并结果
    all_nodes = set(in_deg.keys()).union(out_deg.keys())
    for node in all_nodes:
        centrality_results.append({
            "region": node,
            "period": period,
            "in_degree_centrality": in_deg.get(node, 0),
            "out_degree_centrality": out_deg.get(node, 0),
            "total_degree_centrality": in_deg.get(node, 0) + out_deg.get(node, 0)
        })

# 转为 DataFrame 并保存
centrality_df = pd.DataFrame(centrality_results)
centrality_df.to_csv("/nfs/home/2113_xujialu/zzl/zky/shuffle_new/two_tp/in_out/region_weighted_degree_centrality_1010.csv", index=False)

print("✅ 已完成各区域加权度中心性计算并保存。")
