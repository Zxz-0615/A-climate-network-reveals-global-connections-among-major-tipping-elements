#AMOCindex值提取
import numpy as np
import netCDF4 as nc

def lat_lon_to_index(lat_index, lon_index, lon_len=360):
    """
    将纬度和经度索引映射为一维索引。

    参数：
    - lat_index: 纬度索引
    - lon_index: 经度索引
    - lon_len: 经度的总数 (默认360)

    返回值：
    - 一维索引
    """
    return lat_index * lon_len + lon_index

def process_nc_file(file_path, variable_name, output_npy_path):
    """
    读取nc文件，并将值为1的点转换为一维索引。

    参数：
    - file_path: nc文件路径
    - variable_name: 数据集的变量名称

    返回值：
    - 包含一维索引的列表
    """
    # 打开nc文件
    dataset = nc.Dataset(file_path, 'r')

    # 读取经纬度和数据变量
    latitudes = dataset.variables['lat'][:]  # 纬度数组
    longitudes = dataset.variables['lon'][:]  # 经度数组
    variable_data = dataset.variables[variable_name][:]  # 数据集

    # 获取填充值，检查是否存在 missing_value 或 _FillValue 属性
    if hasattr(dataset.variables[variable_name], '_FillValue'):
        fill_value = dataset.variables[variable_name]._FillValue
    elif hasattr(dataset.variables[variable_name], 'missing_value'):
        fill_value = dataset.variables[variable_name].missing_value
    else:
        fill_value = None

    # 初始化保存值为1的点的索引
    valid_indices = []

    # 遍历数据集的每个点
    for lat_idx in range(len(latitudes)):
        for lon_idx in range(len(longitudes)):
            # 提取数据点的值
            data_value = variable_data[lat_idx, lon_idx]
            
            # 检查数据值是否为1
            if data_value == 1:
                # 计算一维索引
                one_d_index = lat_lon_to_index(lat_idx, lon_idx, lon_len=360)
                # 保存索引
                valid_indices.append(one_d_index)
                print(f"纬度索引: {lat_idx}, 经度索引: {lon_idx}, 一维索引: {one_d_index}")

    dataset.close()

    # 将结果保存为npy文件
    np.save(output_npy_path, np.array(valid_indices))
    print(f"有效索引已保存至 {output_npy_path}")


# 使用示例
file_path = '/nfs/home/2110_wangweiping/zky_climatenetwork/tp/AMOC_env.nc'  # 替换为你的.nc文件路径
variable_name = 'mask'  # 替换为你要处理的数据集变量名称
output_npy_path = '/nfs/home/2110_wangweiping/zky_climatenetwork/tp_index/amoc.npy'
# 打印或处理有效的一维索引
process_nc_file(file_path, variable_name, output_npy_path)

#得到mask_result
import numpy as np
import netCDF4 as nc
import h5py
import os

# 输入裁剪后的大陆气温 NC 文件来获取掩膜和经纬度信息
def Mask(land_data_address):
    f = nc.Dataset(land_data_address, 'r')
    mask = f['permafrost.tif'][:].mask  # mask 为 TRUE 表示没有数据，为 FALSE 表示有数据
    lat = f['lat'][:]  # 获取纬度信息
    lon = f['lon'][:]  # 获取经度信息
    f.close()
    return mask, lat, lon  # 返回掩膜以及对应的纬度、经纬度

# 读取 HDF5 文件并应用掩膜进行筛选
def apply_mask_and_save(h5_data_address, mask, lat, lon, save_address):
    # 打开 HDF5 文件
    with h5py.File(h5_data_address, 'r') as f:
        # 读取现有的温度数据、经纬度信息
        data = f['Global'][:]  # 假设存储的温度数据标签为 'Global'
        h5_lat = f['lat'][:]  # 获取纬度信息
        h5_lon = f['lon'][:]  # 获取经度信息

        # 查找在 h5 文件中的经纬度索引
        lat_indices = np.where(np.isin(h5_lat, lat))[0]
        lon_indices = np.where(np.isin(h5_lon, lon))[0]

        # 使用掩膜对数据进行筛选
        data_selected = data[lat_indices][:, lon_indices, :]
        mask_selected = mask[lat_indices][:, lon_indices]

        # 筛选掩膜为 False 的部分（即有效数据区域）
        valid_lat_indices = np.where(~mask_selected.all(axis=1))[0]
        valid_lon_indices = np.where(~mask_selected.all(axis=0))[0]

        # 过滤掉只保留掩膜为 False 的数据
        data_masked = data_selected[valid_lat_indices][:, valid_lon_indices, :]
        valid_lat = h5_lat[lat_indices][valid_lat_indices]
        valid_lon = h5_lon[lon_indices][valid_lon_indices]
        mask_filtered = mask_selected[valid_lat_indices][:, valid_lon_indices]

    # 创建目录并保存筛选后的数据
    os.makedirs(save_address, exist_ok=True)
    with h5py.File(os.path.join(save_address, 'filtered_temperature_data.h5'), 'w') as f:
        f.create_dataset('temperature_data', data=data_masked)  # 保存只包含掩膜区域的数据
        f.create_dataset('lat', data=valid_lat)
        f.create_dataset('lon', data=valid_lon)
        f.create_dataset('mask', data=mask_filtered)

    print(f"数据处理完成，保存到 {save_address}")

# 主函数，处理多年的数据
if __name__ == "__main__":
    # 文件路径
    absolute_address = '/nfs/home/2110_wangweiping/zky_climatenetwork'
    mask_data_address = absolute_address + '/tp/AMOC_env_180.nc'

    # 循环处理每一年份的 h5 数据
    input_folder = absolute_address + '/ERA5_data/new_result'
    output_folder = absolute_address + '/mask_result/new_mask_result/AMOC_data'
    
    # 读取掩膜数据
    mask, lat, lon = Mask(mask_data_address)

    # 遍历1941到2022年每一年的文件夹
    for year in range(1941, 2023):
        h5_data_address = os.path.join(input_folder, str(year), 'temperature_data_converted.h5')
        save_address = os.path.join(output_folder, str(year))  # 为每一年创建一个单独的保存文件夹

        # 应用掩膜并保存处理后的数据
        apply_mask_and_save(h5_data_address, mask, lat, lon, save_address)


