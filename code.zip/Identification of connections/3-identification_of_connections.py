import numpy as np
import h5py
import csv
import os

# 文件路径
input_file_path_1 = '/nfs/home/2110_wangweiping/zky_climatenetwork/mask_result/new_mask_result/AMOC_data/spatial_average_temperature.h5'
input_file_path_2 = '/nfs/home/2110_wangweiping/zky_climatenetwork/mask_result/new_mask_result/GrIS_data/spatial_average_temperature.h5'

# 加载空间平均后的时间序列数据
with h5py.File(input_file_path_1, 'r') as f:
    spatial_avg_temp_1 = f['spatial_average_temperature'][:]
    print(f"读取第一个时间序列数据成功: 温度时间序列的形状 {spatial_avg_temp_1.shape}")

with h5py.File(input_file_path_2, 'r') as f:
    spatial_avg_temp_2 = f['spatial_average_temperature'][:]
    print(f"读取第二个时间序列数据成功: 温度时间序列的形状 {spatial_avg_temp_2.shape}")

# 滑动窗口计算
length = 365  # 窗口大小
tau_max = 201  # 最大滞后时间
tau_values = []
value_positive = []  # 存储正相关性结果
value_negative = []  # 存储负相关性结果

csv_output_dir = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc'
csv_file_path = os.path.join(csv_output_dir, f"amoc-gris-1941-2023-第一次运行.csv")
first_write = True  # 标记是否是第一次循环

# 滑动窗口计算，保证两个数据集同步滑动
for start in range(0, len(spatial_avg_temp_1) - length, length):  # 通过滑动窗口遍历数据
    end = start + length # 当前窗口的结束位置
    
    # 获取当前窗口内的数据
    temp_1 = spatial_avg_temp_1[start:end]
    temp_2 = spatial_avg_temp_2[start:end]
    
    # 对当前窗口的数据进行标准化处理
    temp_1 = (temp_1 - np.mean(temp_1)) / np.std(temp_1)
    temp_2 = (temp_2 - np.mean(temp_2)) / np.std(temp_2)
    
    # 计算正相关性
    value_positive.append(np.mean(temp_1 * temp_2))

    # 遍历不同的tau，计算每个滞后的相关性
    for tau in range(1, tau_max):
        # 获取滞后后的数据
        out_data = spatial_avg_temp_2[start + tau: start + tau + length]
        in_data = spatial_avg_temp_1[start + tau: start + tau + length]
        temp_3 = (out_data - np.mean(out_data)) / np.std(out_data)
        temp_4 = (in_data - np.mean(in_data)) / np.std(in_data)
        
        # 对滞后数据进行标准化处理
        value_positive.append((np.mean(temp_1 * temp_3) - np.mean(temp_1) * np.mean(temp_3)) / np.sqrt((np.mean(temp_1**2) - np.mean(temp_1)**2) *(np.mean(temp_3**2) - np.mean(temp_3)**2)))
        value_negative.append((np.mean(temp_2 * temp_4) - np.mean(temp_2) * np.mean(temp_4)) / 
                              np.sqrt((np.mean(temp_2**2) - np.mean(temp_2)**2) * (np.mean(temp_4**2) - np.mean(temp_4)**2)))

    # 只保存第一次循环的结果
    if first_write:
        # 合并正负相关性结果
        value_series = np.array(value_positive + value_negative)
        tau_range = np.arange(0, len(value_series))

        # 保存到CSV文件
        with open(csv_file_path, 'w', newline='') as csvfile:
            csv_writer = csv.writer(csvfile)
            csv_writer.writerow(['tau', 'C_ij'])  # 写入列标题
            for tau, cij in zip(tau_range, value_series):
                csv_writer.writerow([tau, cij])  # 写入每一行的数据

        # 标记已经保存了第一次结果
        first_write = False  # 仅保存一次
    else:
        with open(csv_file_path, 'a', newline='') as csvfile:
            csv_writer = csv.writer(csvfile)
            for tau, cij in zip(tau_range, value_series):
                csv_writer.writerow([tau, cij])  # 追加每一行的数据

    print(f"第{start // length + 1}段数据已保存到 CSV 文件.")

print(f"相关性结果已保存到 CSV 文件: {csv_file_path}")
