# AMOC多年数据合并
import numpy as np
import h5py
import os


def merge_temperature_data(input_dir, output_file_path):
    lat_len, lon_len = 13, 31
    total_years = 83  # 从1941到2023年共有83年

    # 初始化大数据结构，365天 * 82年 + 365天 = 365 * 83年
    final_temperature_data = np.zeros((lat_len, lon_len, 365 * total_years))

    current_index = 0

    # 从1942年的数据文件中读取lat和lon
    lat_lon_file_path = os.path.join(input_dir, "1941", "filtered_temperature_data.h5")
    with h5py.File(lat_lon_file_path, 'r') as f:
        lat = f['lat'][:]
        lon = f['lon'][:]

    for year in range(1941, 2022):
        file_path = os.path.join(input_dir, str(year), "filtered_temperature_data.h5")

        with h5py.File(file_path, 'r') as f:
            temperature_data = f['temperature_data'][:, :, :365]  # 取前365天的数据

        final_temperature_data[:, :, current_index:current_index + 365] = temperature_data
        current_index += 365

        print(f"{year} 年的数据已合并")

    # 处理2022年数据，合并全部数据
    final_file_path = os.path.join(input_dir, "2022", "filtered_temperature_data.h5")

    print(f"正在读取2022年的数据: {final_file_path}")

    try:
        with h5py.File(final_file_path, 'r') as f:
            if 'temperature_data' in f:
                temperature_data = f['temperature_data'][:]  # 全部数据
                print(f"2022年数据集大小: {temperature_data.shape}")
                # 将2022年的数据插入到最终数组中
                final_temperature_data[:, :, current_index:current_index + temperature_data.shape[2]] = temperature_data
            else:
                print("数据集 'temperature_data' 不存在")
                return
    except Exception as e:
        print(f"读取2022年数据时出错: {e}")
        return

    print("2022 年的数据已合并")

    # 保存合并后的数据
    with h5py.File(output_file_path, 'w') as f_out:
        f_out.create_dataset('temperature_data', data=final_temperature_data)
        f_out.create_dataset('lat', data=lat)
        f_out.create_dataset('lon', data=lon)

    print(f"数据已成功保存到 {output_file_path}")


# 使用示例
input_dir = '/nfs/home/2110_wangweiping/zky_climatenetwork/mask_result/new_mask_result/AMOC_data/'
output_file_path = '/nfs/home/2110_wangweiping/zky_climatenetwork/mask_result/new_mask_result/AMOC_data/new_merged_temperature_data.h5'

merge_temperature_data(input_dir, output_file_path)

# AMOC平均值计算
import numpy as np
import h5py


def calculate_spatial_average(input_file_path, output_file_path):
    try:
        # 打开合并后的数据文件
        with h5py.File(input_file_path, 'r') as f:
            # 读取数据
            temperature_data = f['temperature_data'][:]  # (lat_len, lon_len, time_steps)
            print(f"读取数据成功: 温度数据形状 {temperature_data.shape}")

        # 在纬度和经度维度（axis=0,1）上求平均值
        spatial_average_temperature = np.mean(temperature_data, axis=(0, 1))
        print(f"空间平均计算完成: 结果形状 {spatial_average_temperature.shape}")

        # 检查结果是否为时间序列 (365*83,)
        assert spatial_average_temperature.shape == (365 * 83,), "结果维度不符合预期"

        # 保存时间序列到新的 HDF5 文件
        with h5py.File(output_file_path, 'w') as f_out:
            f_out.create_dataset('spatial_average_temperature', data=spatial_average_temperature)

        print(f"空间平均时间序列已保存到 {output_file_path}")

    except Exception as e:
        print(f"计算空间平均温度时出错: {e}")


# 使用示例
input_file_path = '/nfs/home/2110_wangweiping/zky_climatenetwork/mask_result/new_mask_result/AMOC_data/new_merged_temperature_data.h5'
output_file_path = '/nfs/home/2110_wangweiping/zky_climatenetwork/mask_result/new_mask_result/AMOC_data/spatial_average_temperature.h5'

calculate_spatial_average(input_file_path, output_file_path)
