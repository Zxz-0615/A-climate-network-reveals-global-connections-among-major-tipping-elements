import numpy as np
import pandas as pd
import os
from collections import defaultdict
import openpyxl

# 文件夹路径
data_dir = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/corr/AMOC_permafrost_correlations_results'
output_dir = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/AMOC_permafrost_correlations_results'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
years = range(1941, 2023)

# 遍历每一年的数据
for year in years:
    # 创建一个 Excel 文件，每年一个文件
    output_file = os.path.join(output_dir, f'AMOC_permafrost_results_{year}.xlsx')
    
    # 读取该年份的 CSV 文件
    csv_file = os.path.join(data_dir, f'AMOC_permafrost_correlations_results_{year}.csv')
    df = pd.read_csv(csv_file)

    # 提取需要的列
    m = df['m'].values  # AMOC索引
    n = df['n'].values  # permafrost索引
    C_ij = df['C_ij'].values  # 相关性矩阵
    W_ij = df['W_ij'].values  # 权重矩阵
    tau = df['tau_distri'].values  # 滞后时间

    # 使用 defaultdict 来简化字典初始化
    AMOC_out_C_dict = defaultdict(float)  # AMOC 出度相关性
    AMOC_out_W_dict = defaultdict(float)  # AMOC 出度权重
    AMOC_out_N_dict = defaultdict(int)    # AMOC 出度计数
    AMOC_in_C_dict = defaultdict(float)   # AMOC 入度相关性
    AMOC_in_W_dict = defaultdict(float)   # AMOC 入度权重
    AMOC_in_N_dict = defaultdict(int)     # AMOC 入度计数
    
    permafrost_in_C_dict = defaultdict(float)  # permafrost 入度相关性
    permafrost_in_W_dict = defaultdict(float)  # permafrost 入度权重
    permafrost_in_N_dict = defaultdict(int)    # permafrost 入度计数
    permafrost_out_C_dict = defaultdict(float) # permafrost 出度相关性
    permafrost_out_W_dict = defaultdict(float) # permafrost 出度权重
    permafrost_out_N_dict = defaultdict(int)   # permafrost 出度计数

    for i in range(len(m)):  # 遍历每一条边
        m_values = m[i]  # AMOC 节点
        n_values = n[i]  # permafrost 节点
        C = C_ij[i]  # 相关性
        W = W_ij[i]
        tau_value = tau[i]

        if 0 < tau_value < 201:
            if m_values not in AMOC_out_C_dict:
                AMOC_out_C_dict[m_values] = 0
                AMOC_out_W_dict[m_values] = 0
                AMOC_out_N_dict[m_values] = 0
            AMOC_out_C_dict[m_values] += C
            AMOC_out_W_dict[m_values] += W
            AMOC_out_N_dict[m_values] += 1

            if n_values not in permafrost_in_C_dict:
                permafrost_in_C_dict[n_values] = 0
                permafrost_in_W_dict[n_values] = 0
                permafrost_in_N_dict[n_values] = 0
            permafrost_in_C_dict[n_values] += C
            permafrost_in_W_dict[n_values] += W
            permafrost_in_N_dict[n_values] += 1

        elif tau_value >= 201:
            if m_values not in AMOC_in_C_dict:
                AMOC_in_C_dict[m_values] = 0
                AMOC_in_W_dict[m_values] = 0
                AMOC_in_N_dict[m_values] = 0
            AMOC_in_C_dict[m_values] += C
            AMOC_in_W_dict[m_values] += W
            AMOC_in_N_dict[m_values] += 1

            if n_values not in permafrost_out_C_dict:
                permafrost_out_C_dict[n_values] = 0
                permafrost_out_W_dict[n_values] = 0
                permafrost_out_N_dict[n_values] = 0
            permafrost_out_C_dict[n_values] += C
            permafrost_out_W_dict[n_values] += W
            permafrost_out_N_dict[n_values] += 1

    # 将累加结果转为 DataFrame
    AMOC_out_result_df = pd.DataFrame({
        'AMOC_index': list(AMOC_out_C_dict.keys()),  # AMOC 索引
        'AMOC_out_N': list(AMOC_out_N_dict.values()),  # AMOC 出度计数
        'AMOC_out_C': list(AMOC_out_C_dict.values()),  # AMOC 出度相关性
        'AMOC_out_W': list(AMOC_out_W_dict.values())   # AMOC 出度权重
    })
    AMOC_in_result_df = pd.DataFrame({
        'AMOC_index': list(AMOC_in_C_dict.keys()),  # AMOC 索引
        'AMOC_in_N': list(AMOC_in_N_dict.values()),  # AMOC 入度计数
        'AMOC_in_C': list(AMOC_in_C_dict.values()),  # AMOC 入度相关性
        'AMOC_in_W': list(AMOC_in_W_dict.values())   # AMOC 入度权重
    })

    permafrost_in_result_df = pd.DataFrame({
        'permafrost_index': list(permafrost_in_C_dict.keys()),  # permafrost 索引
        'permafrost_in_N': list(permafrost_in_N_dict.values()),  # permafrost 入度计数
        'permafrost_in_C': list(permafrost_in_C_dict.values()),  # permafrost 入度相关性
        'permafrost_in_W': list(permafrost_in_W_dict.values())   # permafrost 入度权重
    })
    permafrost_out_result_df = pd.DataFrame({
        'permafrost_index': list(permafrost_out_C_dict.keys()),  # permafrost 索引
        'permafrost_out_N': list(permafrost_out_N_dict.values()),  # permafrost 出度计数
        'permafrost_out_C': list(permafrost_out_C_dict.values()),  # permafrost 出度相关性
        'permafrost_out_W': list(permafrost_out_W_dict.values())   # permafrost 出度权重
    })

    # 将每年数据存储在对应年份的 Excel 文件的不同 sheet 中
    with pd.ExcelWriter(output_file) as writer:
        AMOC_out_result_df.to_excel(writer, sheet_name=f'AMOC_out_result_{year}', index=False)
        AMOC_in_result_df.to_excel(writer, sheet_name=f'AMOC_in_result_{year}', index=False)
        permafrost_in_result_df.to_excel(writer, sheet_name=f'permafrost_in_result_{year}', index=False)
        permafrost_out_result_df.to_excel(writer, sheet_name=f'permafrost_out_result_{year}', index=False)

    print(f"Year {year} processing completed.")
    
    
#每个点inc和inw平均值计算
import os
import pandas as pd

# 定义文件夹路径
folder_path = "/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/AMOC_permafrost_correlations_results"
output_path = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/AMOC_permafrost_correlations_results/point_inc_average'
if not os.path.exists(output_path):
    os.makedirs(output_path)

excel_files = [f for f in os.listdir(folder_path) if f.endswith('.xlsx')]

# 遍历每个Excel文件
for file in excel_files:
    # 获取年份信息（假设文件名格式为 AMOC_permafrost_results_年份.xlsx）
    year = file.split('_')[-1].split('.')[0]
    
    # 读取Excel文件
    file_path = os.path.join(folder_path, file)
    xls = pd.ExcelFile(file_path)
    
    # 创建新的文件名
    new_file_path = os.path.join(output_path, f"processed_{file}")
    
    # 遍历每个sheet并进行计算
    with pd.ExcelWriter(new_file_path, engine='openpyxl') as writer:
        for sheet_name in xls.sheet_names:
            df = pd.read_excel(xls, sheet_name=sheet_name)
            
            # 获取sheet中的所有列名
            columns = df.columns
            
            n_col = [col_name for col_name in columns if 'N' in col_name]  # 获取所有包含'N'的列
            if n_col:  # 如果存在N列
                # 先计算C / N
                for col in columns:
                    if 'C' in col:  # 如果列名中有C
                        # 为newC创建唯一列名，并进行计算C / N
                        new_col_name = f"newC_{col}"  
                        df[new_col_name] = df[col] / df[n_col[0]]  # 计算C/N，并存储在newC列
                
                # 再计算W / N
                for col in columns:
                    if 'W' in col:  # 如果列名中有W
                        # 为newW创建唯一列名，并进行计算W / N
                        new_col_name = f"newW_{col}"
                        df[new_col_name] = df[col] / df[n_col[0]]  # 计算W/N，并存储在newW列
            
            # 保存处理后的sheet到新的Excel文件
            df.to_excel(writer, sheet_name=sheet_name, index=False)

    print(f"Finished processing {file} for year {year}")

