#入度出度计算及绘制
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.colors import Normalize, TwoSlopeNorm

# 读取AMOC数据
AMOC_path = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/spatial/AMOC_permafrost_point_20year/AMOC_out_results_by_period.xlsx'
df_AMOC = pd.read_excel(AMOC_path, sheet_name='1961-1980')

AMOC_index = df_AMOC['AMOC_index']
AMOC_out_n = df_AMOC['AMOC_out_N']
AMOC_out_c_average = df_AMOC['newC_AMOC_out_C']
AMOC_out_w_average = df_AMOC['newW_AMOC_out_W']
AMOC_out_c_sum = df_AMOC['AMOC_out_C']
AMOC_out_w_sum = df_AMOC['AMOC_out_W']

# 读取AMOC索引与经纬度对应关系
index_AMOC = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/index/AMOC_index.csv'
df_index_AMOC = pd.read_csv(index_AMOC)

# 将AMOC_index.csv和df_AMOC根据'AMOC_index'与'index'列进行合并
df_merged_AMOC = pd.merge(df_AMOC, df_index_AMOC[['index', 'Latitude', 'Longitude']], 
                     left_on='AMOC_index', right_on='index', how='left').drop(columns=['index'])

permafrost_path = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/spatial/AMOC_permafrost_point_20year/permafrost_in_results_by_period.xlsx'
df_permafrost = pd.read_excel(permafrost_path, sheet_name='1961-1980')

permafrost_index = df_permafrost['permafrost_index']
permafrost_in_n = df_permafrost['permafrost_in_N']
permafrost_in_c_average = df_permafrost['newC_permafrost_in_C']
permafrost_in_w_average = df_permafrost['newW_permafrost_in_W']
permafrost_in_c_sum = df_permafrost['permafrost_in_C']
permafrost_in_w_sum = df_permafrost['permafrost_in_W']

index_permafrost = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/index/permafrost_index.csv'
df_index_permafrost = pd.read_csv(index_permafrost)

df_merged_permafrost = pd.merge(df_permafrost, df_index_permafrost[['index', 'Latitude', 'Longitude']], 
                         left_on='permafrost_index', right_on='index', how='left').drop(columns=['index'])

latitudes_AMOC = df_merged_AMOC['Latitude']
longitudes_AMOC = df_merged_AMOC['Longitude']
latitudes_permafrost = df_merged_permafrost['Latitude']
longitudes_permafrost = df_merged_permafrost['Longitude']

df_plot_data_AMOC = df_merged_AMOC[['Latitude', 'Longitude', 'AMOC_out_N', 'newC_AMOC_out_C', 'newW_AMOC_out_W', 'AMOC_out_C', 'AMOC_out_W']]
df_plot_data_permafrost = df_merged_permafrost[['Latitude', 'Longitude', 'permafrost_in_N', 'newC_permafrost_in_C', 'newW_permafrost_in_W', 'permafrost_in_C', 'permafrost_in_W']]


#绘图部分
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
def plot_combined_data(data1, data2, title, filename, cmap='RdBu_r'):
    print(f"Data1 Min: {data1.min()}, Max: {data1.max()}")
    print(f"Data2 Min: {data2.min()}, Max: {data2.max()}")
    vmin = min(data1.min(), data2.min())
    vmax = max(data1.max(), data2.max())
    max_abs = max(abs(vmin), abs(vmax))
    vmin, vmax = -max_abs, max_abs
    norm = TwoSlopeNorm(vmin=vmin, vcenter=0, vmax=vmax)
    plt.figure(figsize=(12, 10))
    ax = plt.axes(projection=ccrs.PlateCarree())
    ax.set_extent([-180, 180, -90, 90])

    # 添加陆地背景
    land = cfeature.NaturalEarthFeature('physical', 'land', '110m', 
                                        edgecolor='face', facecolor='lightgray')
    ax.add_feature(land, zorder=1)

    # 绘制AMOC数据
    sc1 = ax.scatter(df_plot_data_AMOC['Longitude'], df_plot_data_AMOC['Latitude'], 
                     c=data1, cmap=cmap, s=10, zorder=2, alpha=0.7, norm=norm)

    # 绘制permafrost数据
    sc2 = ax.scatter(df_plot_data_permafrost['Longitude'], df_plot_data_permafrost['Latitude'], 
                     c=data2, cmap=cmap, s=10, zorder=2, alpha=0.7, norm=norm)

    # 添加网格线
    gridlines = ax.gridlines(draw_labels=True, linestyle='--', color='gray', alpha=0.5)
    gridlines.xlabels_top = False
    gridlines.ylabels_right = False

    # 显示colorbar
    cbar = plt.colorbar(sc1, location='bottom', orientation='horizontal', pad=0.05)
    cbar.set_label('Value', fontsize=12)
    plt.title(title, loc="center", pad=15, fontsize=15)

    # 添加图例
    #plt.legend(loc='upper left', fontsize=12)

    # 保存图片或者显示
    plt.savefig(filename, dpi=800)
    plt.show()

# 绘制AMOC_out_N与permafrost_in_N数据
plot_combined_data(df_plot_data_AMOC['AMOC_out_N'], df_plot_data_permafrost['permafrost_in_N'], 
                   'AMOC_out_N and permafrost_in_N (1961-1980)', '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/spatial/fig/N_AMOC_out_permafrost_in_1961-1980.jpg')

# 绘制AMOC_out_C与permafrost_in_C数据
plot_combined_data(df_plot_data_AMOC['newC_AMOC_out_C'], df_plot_data_permafrost['newC_permafrost_in_C'], 
                   'AMOC_out_C and permafrost_in_C (1961-1980)', '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/spatial/fig/C_AMOC_out_permafrost_in_1961-1980.jpg')

# 绘制AMOC_out_W与permafrost_in_W数据
plot_combined_data(df_plot_data_AMOC['newW_AMOC_out_W'], df_plot_data_permafrost['newW_permafrost_in_W'], 
                   'AMOC_out_W and permafrost_in_W (1961-1980)', '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/spatial/fig/W_AMOC_out_permafrost_in_1961-1980.jpg')

plot_combined_data(df_plot_data_AMOC['AMOC_out_C'], df_plot_data_permafrost['permafrost_in_C'], 
                   'AMOC_out_C_sum and permafrost_in_C_sum (1961-1980)', '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/spatial/fig/sum_C_AMOC_out_permafrost_in_1961-1980.jpg')

# 绘制AMOC_out_W与permafrost_in_W数据
plot_combined_data(df_plot_data_AMOC['AMOC_out_W'], df_plot_data_permafrost['permafrost_in_W'], 
                   'AMOC_out_W_sum and permafrost_in_W_sum (1961-1980)', '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/spatial/fig/sum_W_AMOC_out_permafrost_in_1961-1980.jpg')