import os
import pandas as pd

# 设置输入数据目录
input_dir = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/AMOC_permafrost_correlations_results/point_inc_average'
output_dir = '/nfs/home/2110_wangweiping/zky_climatenetwork/new-cc/two_tp/in_out/spatial/AMOC_permafrost_point_20year'  
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
# 定义时间段
time_periods = { 
    '1941-1960': range(1941, 1961), 
    '1961-1980': range(1961, 1981), 
    '1981-2000': range(1981, 2001), 
    '2001-2022': range(2001, 2023)
}

AMOC_out_results = {period: [] for period in time_periods}
AMOC_in_results = {period: [] for period in time_periods}
permafrost_out_results = {period: [] for period in time_periods}
permafrost_in_results = {period: [] for period in time_periods}

for year in range(1941, 2023):
    # 每年Excel文件路径
    excel_file = os.path.join(input_dir, f'processed_AMOC_permafrost_results_{year}.xlsx')
    
    with pd.ExcelFile(excel_file) as xls:
        # 读取AMOC和permafrost的出度和入度结果
        AMOC_out_result_df = pd.read_excel(xls, sheet_name=f'AMOC_out_result_{year}')
        AMOC_in_result_df = pd.read_excel(xls, sheet_name=f'AMOC_in_result_{year}')
        permafrost_out_result_df = pd.read_excel(xls, sheet_name=f'permafrost_out_result_{year}')
        permafrost_in_result_df = pd.read_excel(xls, sheet_name=f'permafrost_in_result_{year}')
        for period, years in time_periods.items():
            if year in years:
                # 添加该年份的数据到对应时间段的数据中
                AMOC_out_results[period].append(AMOC_out_result_df)
                AMOC_in_results[period].append(AMOC_in_result_df)
                permafrost_out_results[period].append(permafrost_out_result_df)
                permafrost_in_results[period].append(permafrost_in_result_df)
AMOC_out_results_by_period = {}
AMOC_in_results_by_period = {}
permafrost_out_results_by_period = {}
permafrost_in_results_by_period = {}

for period, result_list in AMOC_out_results.items():
    combined_df = pd.concat(result_list, axis=0)
    avg_AMOC_out_result_df = combined_df.groupby('AMOC_index')[['AMOC_out_N', 'AMOC_out_C', 'AMOC_out_W', 'newC_AMOC_out_C', 'newW_AMOC_out_W']].mean().reset_index()
    AMOC_out_results_by_period[period] = avg_AMOC_out_result_df

for period, result_list in AMOC_in_results.items():
    combined_df = pd.concat(result_list, axis=0)
    avg_AMOC_in_result_df = combined_df.groupby('AMOC_index')[['AMOC_in_N', 'AMOC_in_C', 'AMOC_in_W', 'newC_AMOC_in_C', 'newW_AMOC_in_W']].mean().reset_index()
    AMOC_in_results_by_period[period] = avg_AMOC_in_result_df

for period, result_list in permafrost_out_results.items():
    combined_df = pd.concat(result_list, axis=0)
    avg_permafrost_out_result_df = combined_df.groupby('permafrost_index')[['permafrost_out_N', 'permafrost_out_C', 'permafrost_out_W', 'newC_permafrost_out_C', 'newW_permafrost_out_W']].mean().reset_index()
    permafrost_out_results_by_period[period] = avg_permafrost_out_result_df

for period, result_list in permafrost_in_results.items():
    combined_df = pd.concat(result_list, axis=0)
    avg_permafrost_in_result_df = combined_df.groupby('permafrost_index')[['permafrost_in_N', 'permafrost_in_C', 'permafrost_in_W', 'newC_permafrost_in_C', 'newW_permafrost_in_W']].mean().reset_index()
    permafrost_in_results_by_period[period] = avg_permafrost_in_result_df


os.makedirs(output_dir, exist_ok=True)

AMOC_out_file_path = os.path.join(output_dir, 'AMOC_out_results_by_period.xlsx')
AMOC_in_file_path = os.path.join(output_dir, 'AMOC_in_results_by_period.xlsx')
permafrost_out_file_path = os.path.join(output_dir, 'permafrost_out_results_by_period.xlsx')
permafrost_in_file_path = os.path.join(output_dir, 'permafrost_in_results_by_period.xlsx')

with pd.ExcelWriter(AMOC_out_file_path) as writer:
    for period, result_df in AMOC_out_results_by_period.items():
        result_df.to_excel(writer, sheet_name=period, index=False)

with pd.ExcelWriter(AMOC_in_file_path) as writer:
    for period, result_df in AMOC_in_results_by_period.items():
        result_df.to_excel(writer, sheet_name=period, index=False)

with pd.ExcelWriter(permafrost_out_file_path) as writer:
    for period, result_df in permafrost_out_results_by_period.items():
        result_df.to_excel(writer, sheet_name=period, index=False)

with pd.ExcelWriter(permafrost_in_file_path) as writer:
    for period, result_df in permafrost_in_results_by_period.items():
        result_df.to_excel(writer, sheet_name=period, index=False)